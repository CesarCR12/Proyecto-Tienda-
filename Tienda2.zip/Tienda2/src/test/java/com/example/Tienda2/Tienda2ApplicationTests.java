package com.example.Tienda2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tienda2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
